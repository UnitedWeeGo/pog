<?
session_start();
global $configuration;
//$configuration['path'] = '/home/eci/public_html/coachlog/';
$configuration['path'] = 'c:\inetpub\wwwroot\coachlog'; //absolute path to root
$configuration['db'] = ''; //database name
$configuration['host'] = ''; //database host 
$configuration['user'] = ''; //database user
$configuration['pass'] = ''; //database password
?>