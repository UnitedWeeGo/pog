Using the generated code should be straighforward.

In a few words:

- modify configuration.php with your database information (login, password etc)
- include configuration.php, objectfile (timestamped) and class.database.php(if any) in your project.
- create the table for your object using the generated sql query (look in the object file)


If you have any question, post it on the POG Google group and you should receive an answer shortly: http://groups.google.com/group/Php-Object-Generator

or take a look at our in-progress tutorials: http://www.phpobjectgenerator.com/plog/tutorials

or email us at pogguys@phpobjectgenerator.com

Cheers,
The POG Team.

